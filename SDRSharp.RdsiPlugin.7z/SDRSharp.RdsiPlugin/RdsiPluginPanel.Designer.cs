﻿namespace SDRSharp.RdsiPlugin
{
    partial class RdsiPluginPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelConn = new System.Windows.Forms.Label();
            this.groupBoxCtrls = new System.Windows.Forms.GroupBox();
            this.numericUpDownTTL = new System.Windows.Forms.NumericUpDown();
            this.labelTTL = new System.Windows.Forms.Label();
            this.checkBoxND = new System.Windows.Forms.CheckBox();
            this.checkBoxDF = new System.Windows.Forms.CheckBox();
            this.textBoxIP = new System.Windows.Forms.TextBox();
            this.labelIP = new System.Windows.Forms.Label();
            this.numPort = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxCtrls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTTL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPort)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(9, 9);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(75, 23);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Enabled = false;
            this.buttonStop.Location = new System.Drawing.Point(110, 9);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStop.TabIndex = 1;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCount.ForeColor = System.Drawing.Color.Green;
            this.labelCount.Location = new System.Drawing.Point(6, 195);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(44, 15);
            this.labelCount.TabIndex = 2;
            this.labelCount.Text = "Count";
            // 
            // labelConn
            // 
            this.labelConn.AutoSize = true;
            this.labelConn.Location = new System.Drawing.Point(9, 220);
            this.labelConn.Name = "labelConn";
            this.labelConn.Size = new System.Drawing.Size(78, 13);
            this.labelConn.TabIndex = 5;
            this.labelConn.Text = "Not connected";
            // 
            // groupBoxCtrls
            // 
            this.groupBoxCtrls.Controls.Add(this.numericUpDownTTL);
            this.groupBoxCtrls.Controls.Add(this.labelTTL);
            this.groupBoxCtrls.Controls.Add(this.checkBoxND);
            this.groupBoxCtrls.Controls.Add(this.checkBoxDF);
            this.groupBoxCtrls.Controls.Add(this.textBoxIP);
            this.groupBoxCtrls.Controls.Add(this.labelIP);
            this.groupBoxCtrls.Controls.Add(this.numPort);
            this.groupBoxCtrls.Controls.Add(this.label1);
            this.groupBoxCtrls.Location = new System.Drawing.Point(12, 38);
            this.groupBoxCtrls.Name = "groupBoxCtrls";
            this.groupBoxCtrls.Size = new System.Drawing.Size(173, 154);
            this.groupBoxCtrls.TabIndex = 6;
            this.groupBoxCtrls.TabStop = false;
            // 
            // numericUpDownTTL
            // 
            this.numericUpDownTTL.Location = new System.Drawing.Point(54, 119);
            this.numericUpDownTTL.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownTTL.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownTTL.Name = "numericUpDownTTL";
            this.numericUpDownTTL.Size = new System.Drawing.Size(57, 20);
            this.numericUpDownTTL.TabIndex = 6;
            this.numericUpDownTTL.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            // 
            // labelTTL
            // 
            this.labelTTL.AutoSize = true;
            this.labelTTL.Location = new System.Drawing.Point(14, 121);
            this.labelTTL.Name = "labelTTL";
            this.labelTTL.Size = new System.Drawing.Size(27, 13);
            this.labelTTL.TabIndex = 25;
            this.labelTTL.Text = "TTL";
            // 
            // checkBoxND
            // 
            this.checkBoxND.AutoSize = true;
            this.checkBoxND.Location = new System.Drawing.Point(54, 95);
            this.checkBoxND.Name = "checkBoxND";
            this.checkBoxND.Size = new System.Drawing.Size(68, 17);
            this.checkBoxND.TabIndex = 5;
            this.checkBoxND.Text = "No delay";
            this.checkBoxND.UseVisualStyleBackColor = true;
            // 
            // checkBoxDF
            // 
            this.checkBoxDF.AutoSize = true;
            this.checkBoxDF.Checked = true;
            this.checkBoxDF.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxDF.Location = new System.Drawing.Point(54, 71);
            this.checkBoxDF.Name = "checkBoxDF";
            this.checkBoxDF.Size = new System.Drawing.Size(93, 17);
            this.checkBoxDF.TabIndex = 4;
            this.checkBoxDF.Text = "Dont fragment";
            this.checkBoxDF.UseVisualStyleBackColor = true;
            // 
            // textBoxIP
            // 
            this.textBoxIP.Location = new System.Drawing.Point(54, 16);
            this.textBoxIP.Name = "textBoxIP";
            this.textBoxIP.Size = new System.Drawing.Size(104, 20);
            this.textBoxIP.TabIndex = 2;
            this.textBoxIP.Text = "127.0.0.1";
            // 
            // labelIP
            // 
            this.labelIP.AutoSize = true;
            this.labelIP.Location = new System.Drawing.Point(14, 20);
            this.labelIP.Name = "labelIP";
            this.labelIP.Size = new System.Drawing.Size(17, 13);
            this.labelIP.TabIndex = 24;
            this.labelIP.Text = "IP";
            // 
            // numPort
            // 
            this.numPort.Location = new System.Drawing.Point(54, 43);
            this.numPort.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numPort.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numPort.Name = "numPort";
            this.numPort.Size = new System.Drawing.Size(57, 20);
            this.numPort.TabIndex = 3;
            this.numPort.Value = new decimal(new int[] {
            3122,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "Port";
            // 
            // RdsiPluginPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.groupBoxCtrls);
            this.Controls.Add(this.labelConn);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Name = "RdsiPluginPanel";
            this.Size = new System.Drawing.Size(204, 282);
            this.groupBoxCtrls.ResumeLayout(false);
            this.groupBoxCtrls.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTTL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPort)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelConn;
        private System.Windows.Forms.GroupBox groupBoxCtrls;
        private System.Windows.Forms.NumericUpDown numericUpDownTTL;
        private System.Windows.Forms.Label labelTTL;
        private System.Windows.Forms.CheckBox checkBoxND;
        private System.Windows.Forms.CheckBox checkBoxDF;
        private System.Windows.Forms.TextBox textBoxIP;
        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.NumericUpDown numPort;
        private System.Windows.Forms.Label label1;
    }
}
