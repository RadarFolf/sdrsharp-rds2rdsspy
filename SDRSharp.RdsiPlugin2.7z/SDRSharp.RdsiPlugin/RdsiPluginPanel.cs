﻿using System;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using SDRSharp.Common;

namespace SDRSharp.RdsiPlugin
{
    public partial class RdsiPluginPanel : UserControl
    {
        private bool _socketSend = false;
        private int _clientConnect = 0;
        private readonly ISharpControl _control;
        private int _cnt = 0;
        private IPHostEntry _host = null;
        private IPAddress _ipAddress = null;
        private IPEndPoint _localEndPoint = null;
        private Socket _listener = null;
        private Socket _handler = null;

        public RdsiPluginPanel(ISharpControl control)
        {
            InitializeComponent();
            _control = control;
            labelCount.Text = "0";
            labelConn.Text = "Not connected";
            numPort.Value = 3122;
            IPHostEntry _host = Dns.GetHostEntry("localhost");
            int i;
            for (i = 0; i < _host.AddressList.Length; i++)
            {
                if (_host.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                {
                    break;
                }
            }
            _ipAddress = _host.AddressList[i];
            _localEndPoint = new IPEndPoint(_ipAddress, Convert.ToInt32(numPort.Value));
        }

        public void socketSend(String groups)
        {
            if (_socketSend)
            {
                byte[] msg = Encoding.ASCII.GetBytes(groups);
                _handler.Send(msg);
                _cnt++;
                labelCount.Text = _cnt.ToString();
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            _cnt = 0;
            _socketSend = false;
            _clientConnect = 0;
            labelCount.Text = "0";
            labelConn.Text = "Not connected";
            _localEndPoint.Port = Convert.ToInt32(numPort.Value);
            _localEndPoint.Address = _ipAddress;
            try
            {
                _listener = new Socket(_ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                _listener.Bind(_localEndPoint);
                _listener.Listen(1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Listen: " + ex.Message);
                closeListener(); 
                return;
            }

            labelConn.Text = "Connecting ...";
            buttonStart.Enabled = false;
            buttonStop.Enabled = true;
            try
            {
                _listener.BeginAccept(ClientConnected, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("BeginAccept: " + ex.Message);
                buttonStart.Enabled = true;
                buttonStop.Enabled = false;
                labelConn.Text = "Not connected";
                closeListener();
                return;
            }
            while (true)
            {
                if (_clientConnect != 0)
                {
                    break;
                }
                Application.DoEvents();
            }
            if (_clientConnect == 2)
            {
                return;
            }
            labelConn.Text = "Connected";
            buttonStart.Enabled = false;
            buttonStop.Enabled = true;
            numPort.Enabled = false;
            _socketSend = true;
        }

        void ClientConnected(IAsyncResult ar)
        {
            if (_clientConnect == 2)
            {
                return;
            }
            _handler = _listener.Accept();
            _clientConnect = 1;
        }
        private void buttonStop_Click(object sender, EventArgs e)
        {
            _socketSend = false;
            _clientConnect = 2;
            closeListener();
            closeHandler();
            labelConn.Text = "Not connected";
            labelCount.Text = "0";
            numPort.Enabled = true;
            buttonStart.Enabled = true;
            buttonStop.Enabled = false;
        }

        public void closeListener()
        {
            if (_listener != null)
            {
                _listener.Close();
                _listener.Dispose();
                _listener = null;
            }
        }

        public void closeHandler()
        {
            if (_handler != null)
            {
                _handler.Shutdown(SocketShutdown.Both);
                _handler.Close();
                _handler = null;
            }
        }
        public void Close()
        {
            closeHandler();
            closeListener();
        }
    }
}
