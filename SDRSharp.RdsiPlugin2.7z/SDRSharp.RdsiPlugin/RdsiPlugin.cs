﻿using System.Windows.Forms;
using SDRSharp.Common;
using SDRSharp.Radio;

namespace SDRSharp.RdsiPlugin
{
    public class RdsiPlugin : ISharpPlugin
    {
        private const string _displayName = "SDR#2RdsSpy";
        private ISharpControl _control;
        private RdsiPluginPanel _guiControl;

        public UserControl Gui
        {
            get { return _guiControl; }
        }

        public string DisplayName
        {
            get { return _displayName; }
        }

        public void Close()
        {
        }

        public void Initialize(ISharpControl control)
        {
            _control = control;
            _guiControl = new RdsiPluginPanel(_control);
            control.RegisterStreamHook((object)new RdsHwnd(_guiControl), ProcessorType.RDSBitStream);
        }
    }
}
